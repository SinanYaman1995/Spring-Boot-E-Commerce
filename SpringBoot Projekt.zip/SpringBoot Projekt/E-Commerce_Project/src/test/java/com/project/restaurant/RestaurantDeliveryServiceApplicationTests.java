package com.project.restaurant;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestaurantDeliveryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
