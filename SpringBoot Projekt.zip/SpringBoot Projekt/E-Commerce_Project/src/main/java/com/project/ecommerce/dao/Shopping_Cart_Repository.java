package com.project.ecommerce.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.ecommerce.model.jpa.Shopping_Cart;

public interface Shopping_Cart_Repository extends JpaRepository<Shopping_Cart, Long>{
	
	

}
	
	
	
	
	
	
	


