package com.project.ecommerce.model.requests;



public class ResetPassword_Request {

	String Email;

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}
	
	
	
}