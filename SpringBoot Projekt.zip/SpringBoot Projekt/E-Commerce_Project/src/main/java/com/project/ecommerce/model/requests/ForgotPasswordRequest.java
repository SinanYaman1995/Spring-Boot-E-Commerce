package com.project.ecommerce.model.requests;

public class ForgotPasswordRequest {
	
	
	String Email;

	public String getEmail() {
		return Email;
	}

	public void setEmail(String email) {
		Email = email;
	}
	
	
}
